<?php
/**
 * @package		Mb2 Content
 * @version		1.1.0
 * @author		Mariusz Boloz (http://marbol2.com)
 * @copyright	Copyright (C) 2013 Mariusz Boloz (http://marbol2.com). All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
**/



// no direct access
defined('_JEXEC') or die; 
 
function mod_mb2content_image($resize,$url,$link,$item_link,$align,$project_id,$width,$height,$gallery,$gallery_id,$border,$quality){		
		
	
		
	//thumbnails gallery
	if($gallery == 0){ 		
		!mod_mb2content_check_template() ?  $rel=' data-rel="mb2contentPP"' : $rel=' data-rel="prettyPhoto"';	
	}
	else {		
		!mod_mb2content_check_template() ?  $rel=' data-rel="mb2contentPP[gall'.$gallery_id.']"' : $rel=' data-rel="prettyPhoto[gall'.$gallery_id.']"';			
	}
	
	
	
	
	
	//border
	if($border == 1){
		$border_class = 'img-border';
	}
	else{
		$border_class = 'no-border';	
	}
	
		
		
	
	//thumbnail script	
	if($url !=''){
		
		
		
		if($resize == 1){
					
			//check uploaded image format		
			$format_checker = substr($url,-4); 
					
			if ($format_checker == '.jpg'){
				$format = '.jpg';	
			}
			elseif ($format_checker == '.gif'){
				$format = '.gif';	
			}
			elseif ($format_checker == '.png'){
				$format = '.png';	
			}					
									
			// *** 1) Initialise / load image
			$resizeObj = new mb2news_resize(''.$url.'');
				
			// *** 2) Resize image (options: exact, portrait, landscape, auto, crop)
			$resizeObj -> resizeImage($width, $height, 'crop'); 
			
			
			//check if thumbnail folder exist. if not creat it
			if(!is_dir(JPATH_CACHE.'/mod_mb2content')){
				jimport('joomla.filesystem.folder');
				JFolder::create( JPATH_CACHE.'/mod_mb2content');
			}		
				
			// *** 3) Save image
			$resizeObj -> saveImage(''.JPATH_CACHE.'/mod_mb2content/item_'.$project_id.'_'.$width.'x'.$height.''.$format.'', $quality);							
			
			
			//define thumbnail url
			$thumbnail_url = ''.JURI::base(true).'/cache/mod_mb2content/item_'.$project_id.'_'.$width.'x'.$height.''.$format.'';	
		
		
		
		}
		else{
			$thumbnail_url = ''.JURI::base(true).'/'.$url.'';			
		}
		
		
			
		$output = '';
				
				
		
		
		
		
		
		
		
		
		
			
		
		/*-----------------------------------------------------------------------------------*/
		/*	No-link thumbnail
		/*-----------------------------------------------------------------------------------*/	
		if($link == 0) {			
			$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="" /></div></div>';		
			}
		
		
				
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to big image
		/*-----------------------------------------------------------------------------------*/
		elseif($link == 1){
			
			$icon_type = 'icon-resize-full';
				
			$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="" /></div><div class="mark"><div class="link"><a href="'.$url.'"'.$rel.'><i class="icon icon-resize-full"></i></a></div></div></div>';
		}
		
		
		
		
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to post
		/*-----------------------------------------------------------------------------------*/		
		elseif($link == 2){							
				
			$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="" /></div><div class="mark"><div class="link"><a href="'.$item_link.'"><i class="icon icon-link"></i></a></div></div></div>';
			
			
		}
		
		
		
		
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to post and big image
		/*-----------------------------------------------------------------------------------*/	
		elseif($link == 3){
			
			$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="" /></div><div class="mark"><div class="links"><a href="'.$url.'"'.$rel.'><i class="icon icon-resize-full"></i></a><a href="'.$item_link.'"><i class="icon icon-link"></i></a></div></div></div>';
			
				
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
						
		echo $output;			
	}						
}