<?php
/**
 * @package		Mb2 Content
 * @version		1.1.0
 * @author		Mariusz Boloz (http://marbol2.com)
 * @copyright	Copyright (C) 2013 Mariusz Boloz (http://marbol2.com). All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
**/



defined('_JEXEC') or die;


/*-----------------------------------------------------------------------------------*/
/*	Check template
/*-----------------------------------------------------------------------------------*/
function mod_mb2content_check_template(){	
	
	$app = JFactory::getApplication();
	$current_template = $app->getTemplate();
	
	//add to array templates name
	$templates = array('gamma');
			
		
	//get template author name
	$templ_url = JURI::base(false).'/templates/'.$current_template.'/templateDetails.xml';		
	$tmpl_xml=simplexml_load_file($templ_url);	
	$xml_tmpl_aurhor = $tmpl_xml->author;
	$no_space_tmpl_author = str_replace(' ','',$xml_tmpl_aurhor);		
	$tmpl_author = strtolower($no_space_tmpl_author);
	
	
	
	foreach($templates as $template){		
		
		if($template === $current_template && $tmpl_author === 'mariuszboloz'){			
			return true;	
		}		
		else{			
			return false;	
		}		
		
	}	
	
			
}









/*-----------------------------------------------------------------------------------*/
/*	Change 1 to 'true' and 0 to 'false'
/*-----------------------------------------------------------------------------------*/
function mod_mb2content_true_false($param){	
	if($param == 0){
		$param = 'false';	
	}
	else{
		$param = 'true';
	}	
	return $param;			
}








/*-----------------------------------------------------------------------------------*/
/*	Custom word limit
/*-----------------------------------------------------------------------------------*/	
function mb2news_word_limit($string,$word_limit,$end_char){	
	
	
	//check if user use word limit
	if($word_limit !='' && $word_limit < 999){
		
		$content_limit = strip_tags($string);
		$words = explode(" ",$content_limit);
		$new_string = implode(" ",array_splice($words,0,$word_limit));	
		$word_count = str_word_count($string);
		
		
		//get end of word limit
		if($end_char !=''){
			if($word_count > $word_limit){		
			$is_end_char = $end_char;
			}		
			else{
			$is_end_char = '';	
			}
		}
		else{
			$is_end_char = '';
		}			
		
		echo ''.JHTML::_('content.prepare', $new_string).''.$is_end_char.'';		
		
	}
	
	else{		
		echo JHTML::_('content.prepare', $string);		
	}
		
	
}










/*-----------------------------------------------------------------------------------*/
/*	Layout function
/*-----------------------------------------------------------------------------------*/	
function mod_mb2content_layout(
	$mod_id = 0,
	$wrap_width = 1080,
	$get_item_media_width = 50,
	$cols = 3,
	$wrap_id = 'mb2-content-wrap',
	$inner_class = 'mb2-content-item-inner',
	$media_class = 'mb2-content-item-media',
	$details_class = 'mb2-content-item-details',
	$media_inner_class = 'mb2-content-item-media-inner',
	$item_margin = '',
	$media_margin = '',
	$item_layout = ''
	){
	
	$doc = JFactory::getDocument();
	$module = JModuleHelper::getModule('mod_mb2content');
	$params = new JRegistry();
	$params->loadString($module->params);
	
	
	
	//get params
	$carousel_on = $params->get('carousel_on');	
	
		
			
			
										
	
	
			
	//calculate items width
	$cal_item_width = $wrap_width/$cols;	
	$item_width = round($cal_item_width,0,PHP_ROUND_HALF_DOWN);	
	
	if($carousel_on == 1){
		$item_max_width = 100;
	}
	else{
		$item_max_width = (100/$cols);
	}
		
		
		
					
	//new item width ('-' margin left and right)		
	$margin_arr = explode(' ',trim($item_margin));
	$margin_right = preg_replace('/[^0-9]/',' ',$margin_arr[1]);
	$margin_left = preg_replace('/[^0-9]/',' ',$margin_arr[3]);				
	$new_item_width = $item_width - $margin_left - $margin_right;
	$new_wrap_width = $wrap_width - $margin_left - $margin_right;
			
			
			
			
		if($item_layout == 'media-above' || $item_layout == 'only-image' || $item_layout == 'only-desc' || $get_item_media_width == 100){				
			//calculate media item width
			$item_media_width = $new_item_width;
			$item_media_max_width = 100;
			
			//calculate description item width						
			$item_desc_width = $new_item_width;
			$item_desc_max_width = 100;				
		}
		else {				
			//calculate media item width
			$media_width = $get_item_media_width / 100;
			$cal_item_media_width = $new_item_width * $media_width; 		
			$item_media_width = round($cal_item_media_width,0,PHP_ROUND_HALF_DOWN);
			$item_media_max_width = $get_item_media_width;
				
			//calculate description item width				
			$desc_width = (100 - $get_item_media_width) / 100;
			$cal_desc_width = $new_item_width * $desc_width;		
			$item_desc_width = round($cal_desc_width,0,PHP_ROUND_HALF_DOWN);
			$item_desc_max_width = 100 - $get_item_media_width;
		}
		
		
		
		
		
		
	//get wrap style
	$wrap_width_style = '#'.$wrap_id.'-'.$mod_id.'{width:'.$wrap_width.'px;max-width:100%;}';	
		
							
	//get item style		
	$item_style = '#'.$wrap_id.'-'.$mod_id.' .item-col-'.$cols.'{width:'.$item_width.'px;max-width:'.$item_max_width.'%;}#'.$wrap_id.'-'.$mod_id.' .'.$inner_class.'{margin:'.$item_margin.';}#'.$wrap_id.'-'.$mod_id.' .'.$media_class.'{width:'.$item_media_width.'px;max-width:'.$item_media_max_width.'%;}#'.$wrap_id.'-'.$mod_id.' .'.$details_class.'{width:'.$item_desc_width.'px;max-width:'.$item_desc_max_width.'%;}#'.$wrap_id.'-'.$mod_id.' .'.$inner_class.' .'.$media_inner_class.'{margin:'.$media_margin.';}';			
		
		
	//output styles	
	$doc->addStyleDeclaration($wrap_width_style.$item_style);				
	
	
			
}








/*-----------------------------------------------------------------------------------*/
/*	Style declaration function
/*-----------------------------------------------------------------------------------*/	
function mod_mb2content_style($module_id,$custom_css,$active_color,$color,$link_color,$link_hover_color,$title_color,$meta_color,$fa){	
	
	$doc = JFactory::getDocument();	
	
	
	
	$module = JModuleHelper::getModule('mod_mb2content');
	$params = new JRegistry();
	$params->loadString($module->params);
	
	
	
	
	
	
	
	//main styles
	if(!mod_mb2content_check_template()){
		if($fa == 1){
			$doc->addStyleSheet(JURI::base(true).'/modules/mod_mb2content/css/font-awesome/css/font-awesome.min.css');
		}			
		$doc->addStyleSheet(JURI::base(true).'/modules/mod_mb2content/css/mod_mb2content.css');		
	}
	
	
	
	
	
	
	//active color
	if($active_color !=''){		
		$active_color_style = '#mb2-content-wrap-'.$module_id.'.mb2-content .content-img:hover .mark a,#mb2-content-wrap-'.$module_id.' .mb2-content-nav .prev:hover,
#mb2-content-wrap-'.$module_id.' .mb2-content-nav .next:hover,#mb2-content-wrap-'.$module_id.' .mb2-content-nav .pager a.selected,#mb2-content-wrap-'.$module_id.'.mb2-content .content-img:hover .img-border{background-color:'.$active_color.';}';		
		$doc->addStyleDeclaration($active_color_style);		
	}
	
	
	
	
	
	
	//text color
	if($color !=''){		
		$color_style = '#mb2-content-wrap-'.$module_id.'{color:'.$color.';}';	
		$doc->addStyleDeclaration($color_style);		
	}
	
	
	
	
	
	//links color (normal and hover)
	if($link_color !='' || $link_hover_color !=''){			
		if($link_color !=''){			
			$link_color_style = '#mb2-content-wrap-'.$module_id.' a{color:'.$link_color.';}';		
			$doc->addStyleDeclaration($link_color_style);			
		}		
		
		if($link_hover_color !=''){		
			$link_hover_color_style = '#mb2-content-wrap-'.$module_id.' a:hover,#mb2-content-wrap-'.$module_id.' a:active,#mb2-content-wrap-'.$module_id.' a:focus{color:'.$link_hover_color.';}';		
			$doc->addStyleDeclaration($link_hover_color_style);	
		}		
	}
	
	
	
	
	
	//title color
	if($title_color !=''){
		$title_color_style = '#mb2-content-wrap-'.$module_id.' .mb2-content-item-title,#mb2-content-wrap-'.$module_id.' .mb2-content-item-title a{color:'.$title_color.';}';		
		$doc->addStyleDeclaration($title_color_style);		
	}
	
	
	
	
	
	
	
	
	//article info color
	if($meta_color !=''){
		$meta_color_style = '#mb2-content-wrap-'.$module_id.' .mb2-content-item-meta{color:'.$meta_color.';}';		
		$doc->addStyleDeclaration($meta_color_style);		
	}
	
	
	
	
	
	
	
	
	
	
		
	
	
	if($custom_css !=''){
		$doc->addStyleDeclaration(''.$custom_css.'');			
	}	
}








/*-----------------------------------------------------------------------------------*/
/*	Script declaration
/*-----------------------------------------------------------------------------------*/	
function mod_mb2content_script($module_id,$jq,$jq_no_conf,$jq_v,$pp,$carousel,$swipe,$lightbox_image,$hover_effect){
	
	$doc = JFactory::getDocument();
	$module = JModuleHelper::getModule('mod_mb2content');
	$params = new JRegistry();
	$params->loadString($module->params);
	
	
	
	//check if custom script file must be loaded
	$custom_scripts = ($pp == 1 && $lightbox_image != 0) || $carousel == 1;
	
	
	
	
	if(!mod_mb2content_check_template()){
	
	
	
	
		//get jquery
		if(version_compare(JVERSION,'3.0','>')){		
			JHtml::_('jquery.framework', true, true);	
		}
		else{				
			if($jq == 1){
				$doc->addScript('https://ajax.googleapis.com/ajax/libs/jquery/'.$jq_v.'/jquery.min.js');			
			}
			if($jq_no_conf == 1){			
				$doc->addScript(JURI::base(true).'/modules/mod_mb2content/js/jquery.noConflict.js');			
			}	
		}
		
		
		
		
		
			
		
		//get fredSel carousel 
		if($carousel == 1){		
			$doc->addScript(JURI::base(true).'/modules/mod_mb2content/js/jquery.carouFredSel-6.2.1-packed.js');	
		}
		
		
		
		
		//get swipe plugin
		if($swipe == 1){
			$doc->addScript(JURI::base(true).'/modules/mod_mb2content/js/jquery.touchSwipe.min.js');			
		}		
	
	
	
		
		
		
		
		//get prettyPhoto
		if($pp == 1 && $lightbox_image != 0){		
			$doc->addStyleSheet(JURI::base(true).'/modules/mod_mb2content/css/prettyPhoto/css/prettyPhoto.css');	
			$doc->addScript(JURI::base(true).'/modules/mod_mb2content/js/jquery.prettyPhoto.js');			
		}
		
		
		
		
			
		
	}
	
	
	
	
	
	
	if($custom_scripts){
		$doc->addScript(JURI::base(true).'/modules/mod_mb2content/js/mod_mb2content.js');
	}
	
	
	
	
	
	
	
	
	
	
	
		
}
	
	
		
		
	
	









/*-----------------------------------------------------------------------------------*/
/*	Carousel function
/*-----------------------------------------------------------------------------------*/
function mod_mb2content_carousel($module_id,$cols,$carousel_on,$carousel_control_nav,$carousel_pause_time,$carousel_direct_nav,$carousel_auto,$carousel_scroll,$carousel_min_item,$carousel_nav_top_position,$carousel_touch,$item_margin){
	
	
	$doc = JFactory::getDocument();
	
	
	
	
	
	
	if($carousel_on == 1){
				
		
		//get navigation
		$carousel_direct_nav == 1 ? $prev = 'prev: \'#mb2-content-prev-'.$module_id.'\',' : $prev = '';
		$carousel_direct_nav == 1  ? $next = 'next: \'#mb2-content-next-'.$module_id.'\',' : $next = '';		
		$carousel_control_nav == 1 ? $pager = 'pagination: \'#mb2-content-pager-'.$module_id.'\',' : $pager = '';				
		
		
			
		
			
			
				
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Get acrousel navigation
		/*-----------------------------------------------------------------------------------*/
		if($carousel_direct_nav == 1 || $carousel_control_nav == 1){ ?>
		<div class="mb2-content-nav">
        	<div class="mb2-content-nav-inner">            
            	<?php if($carousel_direct_nav == 1){?>
					<a id="mb2-content-prev-<?php echo $module_id; ?>" class="prev" href="#"><i class="fa fa-angle-left"></i></a>
               		<a id="mb2-content-next-<?php echo $module_id; ?>" class="next" href="#"><i class="fa fa-angle-right"></i></a>				
				<?php } ?>                               
                <?php if($carousel_control_nav == 1){?>
					<div id="mb2-content-pager-<?php echo $module_id; ?>" class="pager"></div><!-- end .pager -->					
				<?php } ?>                
            </div>
        </div><!-- end .mb2-content-module-nav -->	
    	<?php
		
			
			
			/*-----------------------------------------------------------------------------------*/
			/*	Get navigation position
			/*-----------------------------------------------------------------------------------*/		
			//get new item width ('-' margin left and right)		
			$margin_arr = explode(' ',trim($item_margin));
			$margin_right = preg_replace('/[^0-9]/',' ',$margin_arr[1]);			
			
			if($carousel_direct_nav == 1){
				$doc->addStyleDeclaration('#mb2-content-wrap-'.$module_id.' .mb2-content-nav{top:'.$carousel_nav_top_position.'px;right:'.str_replace(' ','',$margin_right).'px;}');	
			}	
			
			
			if($carousel_direct_nav == 0 && $carousel_cntrol_nav == 1){				
				$doc->addStyleDeclaration('#mb2-content-wrap-'.$module_id.' .mb2-content-nav .pager{right:'.str_replace(' ','',$margin_right).'px;}');
					
			}
			
			
			
		}		
		
		
	}
	
}


















/*-----------------------------------------------------------------------------------*/
/*	Artcile image
/*-----------------------------------------------------------------------------------*/
function mod_mb2content_image($crop=1,$url,$link=0,$item_link=null,$item_title=null,$align='none',$width=100,$height=100,$gallery_id=0,$border=0,$quality=100){
		
	
	//get params
	$module = JModuleHelper::getModule('mod_mb2content');
	$params = new JRegistry();
	$params->loadString($module->params);
	
		
		
	//thumbnails gallery
	if($params->get('lightbox_image') == 1){
	
		if($params->get('lightbox_gallery') == 0){			
			$rel=' data-rel="prettyPhoto"';	
		}
		else {
			$rel=' data-rel="prettyPhoto[mod_mb2content_gall'.$gallery_id.']"';
		}	
	}
	else{
		$rel='';	
	}
	
	
	
	
	
	//get size of mark links
	if($width < 200){
		$mark_size = 'small';
	}
	else{
		$mark_size = '';	
	}
	
	
		
	
	
	//border
	if($border == 1){
		$border_class = 'img-border';
	}
	else{
		$border_class = 'no-border';	
	}
	
		
		
	
	//thumbnail script	
	if($url !=''){
		
		
		
		if($crop == 1){
					
			//check uploaded image format		
			$format_checker = substr($url,-4); 
					
			if ($format_checker == '.jpg'){
				$format = '.jpg';	
			}
			elseif ($format_checker == '.gif'){
				$format = '.gif';	
			}
			elseif ($format_checker == '.png'){
				$format = '.png';	
			}					
									
			// *** 1) Initialise / load image
			$resizeObj = new mb2news_resize(''.$url.'');
				
			// *** 2) Resize image (options: exact, portrait, landscape, auto, crop)
			$resizeObj -> resizeImage($width, $height, 'crop'); 
			
			
			//check if thumbnail folder exist. if not creat it
			if(!is_dir(JPATH_CACHE.'/mod_mb2content')){
				jimport('joomla.filesystem.folder');
				JFolder::create( JPATH_CACHE.'/mod_mb2content');
			}		
						
			
			//get image name
			$image_name = mod_mb2content_image_name($url);				
				
			// *** 3) Save image
			$resizeObj -> saveImage(''.JPATH_CACHE.'/mod_mb2content/'.$image_name.'_'.$width.'x'.$height.$format.'', $quality);			
			
			//define thumbnail url
			$thumbnail_url = ''.JURI::base(true).'/cache/mod_mb2content/'.$image_name.'_'.$width.'x'.$height.$format.'';	
		
		
		
		}
		else{
			$thumbnail_url = ''.JURI::base(true).'/'.$url.'';			
		}
		
		
			
		$output = '';
				
				
		
		
		
		
		
		
		
		
		
			
		
		/*-----------------------------------------------------------------------------------*/
		/*	No-link thumbnail
		/*-----------------------------------------------------------------------------------*/	
		if($link == 0) {			
			$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="" /></div></div>';		
			}
		
		
				
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to big image
		/*-----------------------------------------------------------------------------------*/
		elseif($link == 1){
			
			
			if($params->get('hover_effect') == 0){
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><a href="'.$url.'"'.$rel.' title=""><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></a></div></div>';
				
			}
			else{				
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></div><div class="mark '.$mark_size.'"><div class="link"><a href="'.$url.'"'.$rel.' title="'.htmlspecialchars($item_title).'"><i class="fa fa-expand"></i></a></div></div></div>';			
			}
				
			
		}
		
		
		
		
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to post
		/*-----------------------------------------------------------------------------------*/		
		elseif($link == 2){	
		
		
			if($params->get('hover_effect') == 0){
									
				
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><a href="'.$item_link.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></a></div></div>';
			
			
			}
			else{		
				
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></div><div class="mark '.$mark_size.'"><div class="link"><a href="'.$item_link.'"><i class="fa fa-link"></i></a></div></div></div>';
				
				
			}
			
			
		}
		
		
		
		
		
		
		
		/*-----------------------------------------------------------------------------------*/
		/*	Thumbnail as link to post and big image
		/*-----------------------------------------------------------------------------------*/	
		elseif($link == 3){
			
			
			if($params->get('hover_effect') == 0){
				
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><a href="'.$item_link.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></a></div></div>';
				
			}
			else{
				$output .= '<div class="content-img align-'.$align.'" style="width:'.$width.'px;max-width:100%;height:auto;"><div class="'.$border_class.'"><img class="img-opacity" style="max-width:100%;height:auto;" src="'.$thumbnail_url.'" alt="'.htmlspecialchars($item_title).'" /></div><div class="mark '.$mark_size.'"><div class="links"><a href="'.$url.'"'.$rel.' title="'.htmlspecialchars($item_title).'"><i class="fa fa-expand"></i></a><a href="'.$item_link.'"><i class="fa fa-link"></i></a></div></div></div>';
				
			}			
			
				
		}		
		
		
						
		echo $output;			
	}						
}














/*-----------------------------------------------------------------------------------*/
/*	Image name function
/*-----------------------------------------------------------------------------------*/
function mod_mb2content_image_name($url){	
	
	//get file name
	$img_parts = pathinfo($url);
					
	if(!isset($img_parts['filename'])){
		$img_parts['filename'] = substr($img_parts['basename'], 0, strrpos($img_parts['basename'], '.'));
	} 	
						
	return $img_parts['filename'];
		
	
}