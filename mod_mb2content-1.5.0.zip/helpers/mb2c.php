<?php
/**
 * @package		Mb2 Content
 * @version		1.4.0
 * @author		Mariusz Boloz (http://marbol2.com)
 * @copyright	Copyright (C) 2013 - 2015 Mariusz Boloz (http://marbol2.com). All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
**/



defined('_JEXEC') or die;



abstract class JHtmlMb2c {
	
			
		
	
	
	
	
}